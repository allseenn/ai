

==============================================================================
Java 3D(TM) 1.1.3
==============================================================================

This is the 1.1.3 version of Java 3D(TM).

------------------------------------------------------------------------------
DISTRIBUTING Java 3D(TM) WITH YOUR JAVA(TM) PROGRAMS
------------------------------------------------------------------------------

Sun Microsystems allows vendors to distribute the Java 3D Runtime
environment with their Java programs, provided they follow the terms
of the Java 3D Binary Code License agreement.

This document uses the term "vendors" to refer to licensees,
developers, and independent software vendors (ISVs) who license and
distribute Java 3D with their Java programs.

------------------------------------------------------------------------------
REQUIRED vs. OPTIONAL FILES
------------------------------------------------------------------------------

Vendors must follow the terms of the Java 3D Binary Code License agreement,
which includes these terms:

 - Don't arbitrarily subset Java 3D. You may, however, omit those files
   that have been designated below as "optional".

 - Include in your product's license the provisions called out
   in the Java 3D Binary Code License.


==============================================================================
           BUNDLING AND RUNNING JAVA 3D
==============================================================================

------------------------------------------------------------------------------
BUNDLING JAVA 3D
------------------------------------------------------------------------------

The release of Java 3D for Win32 comes with its own installer that
makes it suitable for downloading by end users. Java application
developers have the option of not bundling Java 3D with their software.
Instead, they can direct end-users to download and install the Java 3D
software themselves.

Solaris versions of Java 3D do not have an installer. Software
developers should bundle Java 3D and an installer with their software.

Required Files
--------------

The following files are required.


	<installdir>\jre\bin\J3D.dll
	<installdir>\jre\bin\j3daudio.dll
	<installdir>\jre\lib\ext\vecmath.jar
	<installdir>\jre\lib\ext\j3dcore.jar
	<installdir>\jre\lib\ext\j3daudio.jar
	<installdir>\jre\lib\ext\j3dutils.jar


If an application developer bundles Java 3D with their application,
all required files must be included.


Optional Files
--------------

Files in the following directories and files are optional:


	<installdir>\demo\java3d
	<installdir>\j3d-utils-src.jar


An application developer may include these with their Java 3D application,
but is not required to do so.


==============================================================================
Requirements
==============================================================================

This version of Java 3D for WindowsNT 4.0, Windows95 and Windows98 requires
the following:
    - Java2 SDK 1.2 or later
    - OpenGL 1.1 from Microsoft or an accelerator which supports OpenGL 1.1.
      For more information on OpenGL see www.opengl.org.
    - For WindowsNT 4.0, Service Pack 3 is required

==============================================================================
Installation
==============================================================================


To install the Java 3D Runtime environment into the JRE, run the
executable by double-clicking on the java3d1_1_3-win-opengl-rt.exe
icon.  Java 3D should be installed in the jre subdirectory of 1.2 JRE.
By default, this should be "C:\Program Files\JavaSoft\Jre\1.2".

You may remove the java3d1_1_3-win-opengl-rt.exe file after you are
done extracting it.

NOTE: if Java 3D is installed in the default location, you do not need
to include the J3D jar files in your CLASSPATH, nor do you need to
include the J3D shared libraries in your PATH.  You should include "."
in your CLASSPATH or ensure that CLASSPATH is not set.


If, after installation, you get the following error message while
running a Java 3D program:

java.lang.UnsatisfiedLinkError: no J3D in shared library path
        at java.lang.Throwable.<init>(Compiled Code)
        at java.lang.Error.<init>(Compiled Code)
        at java.lang.LinkageError.<init>(Compiled Code)
        at java.lang.UnsatisfiedLinkError.<init>(Compiled Code)
        at java.lang.Runtime.loadLibrary0(Compiled Code)
        at java.lang.System.loadLibrary(Compiled Code)
        at javax.media.j3d.UniverseManager.<init>(Compiled Code)
        at
        at HelloUniverse.<init>(Compiled Code)
        at HelloUniverse.main(Compiled Code)

It is most likely because OpenGL and/or the OpenGL GLU utilities are
either not installed on the machine.

For information on OpenGL and how to get it, see the OpenGL web page at
http://www.opengl.org/


==============================================================================
Running Java 3D in a Browser
==============================================================================



Java Plug-in is installed into JRE 1.2 by default.  If you install the
Runtime version of Java into the JRE, you can then run applets that
have a modified HTML page.  Refer to the following URL for information
on using the Java Plug-in 1.2 HTML Converter and running applets
using Java Plug-in:

	http://java.sun.com/products/plugin/




==============================================================================
Changes since 1.1.2
==============================================================================
    Memory Release
        Some work was done to help ensure that Java 3D releases memory
        when a branch graph is detached from the scene graph.  In some
        cases you may need to detach the View from the scene graph
        to release the memory. 

    Bugs Fixed:
        - Line/polytope intersection fails for line longer than 1.0
        - NullPointerException when de-iconifying application
        - Setting Texture reference from user thread can cause deadlock.
        - Alpha setTriggerTime() fail to set stopTime
        - AccessControlException when a visible Canvas3D is added to a View
        - software decompressor produces bad colors from mesh references
        - Can't restart RotPosScaleTCBSplinePathInterpolator
        - Quaternion interpolation causes bad rotations
        - In segmentAndQuad, the return value of dist[0] is a ratio, 
          not a distance.
        - fog scoping methods throw CapabilityNotSetException even it is set
        - RotationInterpolator created with null Alpha cannot be restarted
        - Lightwave TestParse can't load SpaceFighters


==============================================================================
Utilities:
==============================================================================

This release includes utilities for Java 3D.  These utilities are still
being defined and under development.  Much of the source for these utilities
is also provided.  The API for these utilities may change in future releases.

NOTE:  The Javadocs for all utilities are available from the Java 3D
Implementation Download Web Page:
http://java.sun.com/products/java-media/3D/download.html.  At the bottom
of the page there is a section titled: "Download the Java 3D 1.1.3
Implementation Documentation".

The following utilities are provided in this release:

        - Java Sound Audio Device
	- Some predefined Mouse based behaviors
	- Picking utilities including predefined picking behaviors
	- Geometry creation classes for Box, Cone, Cylinder, and Sphere
	- A Text2D utility
	- A Universe Builder - SimpleUniverse
	- An Image Loading utility
	- A Normal Generator utility
	- A Polygon Triangulator utility
	- Preliminary triangle stripifier
	- Spline-based path interpolators
	- Preliminary Wavefront .obj loader
	- Preliminary Lightwave 3D File Loader
	- A utility to generate compressed geometry for use with Java 3D's
          CompressedGeometry node.

==============================================================================
Known Problems
==============================================================================


Core Bugs (j3d and vecmath)
      - ReadRaster does not clip to screen correctly
      - MediaContainer node cloned improperly
      - SwitchValueInterpolator needs to handle firstChild > lastChild index
      - Compiles of nested BranchGroups consumes more memory than single
        root compile
      - Back clip distance in Clip node not scaled correctly
      - SceneAntialiasing setting of PREFERRED is ignored
      - Geometry Collision does not implement points/surface, line/line, or
        line/point
      - Java 3D cannot handle more than 64 lights
      - Cached eye position not set in compatibility mode
      - Cached transforms not set in compatibility mode
      - Region of Influence/Scope changes to Light/Fog doesn't effect
        static objects
      -	Shape3D memory not freed when unassigned if associated
	appearance object is live
      - Java 3D classes and threads are not cleaned up and cannot be unloaded
      - After switch from Mixed mode to normal mode,
	IllegalSharingException thrown
      - Non-Congruent matrix above view platform will kill the traverser thread
      -	Illegal rendering state exceptions kill Traverser thread
      - Billboard node not synchronized with view platform changes
      - getBounds returns null for non-live scene graphs
      - wakeupOn fails to register a condition when called with the same
        reference twice
      - Collision does implicit conversions of bounds types
      - PathInterpolator's setKnot method does not validate inputs
      - Sound performance on native threads is bad
      -	Not all physical coexistence center policies are implemented
      -	HMD mode not yet implemented
      -	SceneGraphCycleException checking needs to be turned on.
      -	Occasional spikes in Doppler calculation causes wild
	exaggerated pitch shifting
      -	Filtering causes loud, sweeping resonance to be added to most
	sounds
      -	Cross-talk cancellation for sound playback in not implemented
      -	setReverbDelay(null) of AuralAttributes return incorrect value
      -	HEAD_PREDICTOR and HAND_PREDICTOR policies not implemented
      -	Geometry-based picking is not supported for CompressedGeometry.
      -	Geometry collision not supported for compressed geometry
      -	Multiple sample channels are not always synchronized when
	started
      -	GMatrix SVD does not work correctly for some cases.
      -	Java3D does unneeded redraws for window events
      -	Loading HTML page or Java 3D applet while sound is playing
	may cause exception
      - Extrusion contures for Font3D don't produce smooth normals
      - Multiple views of a Switch node incorrect
      - Multiple repaints per scene graph change
      - ImageComponent2D with no image set causes segmentation fault
      - ViewPlatforms do not work correctly under Switch nodes

Utility Bugs
      - ObjectFile Loader material properties support needs to be expanded
      - FourByFour generates SecurityException when trying to write out
	the high score file


Windows-specific Bugs
      -	Bug in Symantec JIT causes the GearBox example to render
	incorrectly.
      -	Symantec JIT issues warning when running FourByFour example
      - PureImmediate mode does not work after paint() event on Win95 with ogl



